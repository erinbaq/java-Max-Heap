package Assignment2;

//Russ Erin Baquiran
//CS2400
//Assignment 2- max-heap (sequential and optimal)


import java.util.Arrays;
import java.util.ArrayList;

public class MaxHeap<T extends Comparable<? super T>>{
	private T[] heap;
	private int last;
	private boolean initialized = false;
	private static final int DEFAULT_CAPACITY = 50;
	private int swapCount = 0;
	
	public MaxHeap()
	{
		this(DEFAULT_CAPACITY);
	}
	
	public MaxHeap(int cap)
	{
		capCheck(cap);
		
		@SuppressWarnings("unchecked")
		T[] temp = (T[])new Comparable[cap + 1];
		heap = temp;
		last = 0;
		initialized = true;
	}
	
	public MaxHeap(ArrayList<T> input)
	{
		capCheck(input.size());
		@SuppressWarnings("unchecked")
		T[] temp = (T[]) new Comparable[input.size() + 1];
		heap = temp;
		last = input.size();
		for(int index = 0; index < input.size(); index++)
		{
			heap[index + 1] = input.get(index);
		}
		
		initialized = true;
		
		for (int root = last/2; root > 0; root--)
      {
          reheap(root);
      }
		
	}
	
	private void capCheck(int cap)
	{
		if(cap < DEFAULT_CAPACITY)
		{
			cap = DEFAULT_CAPACITY;
		}
	}
	
	public void add(T newEntry)
	{
		checkInitialization();
		int newest = last + 1;
		int parent = newest / 2;
		
		while( (parent > 0 ) && newEntry.compareTo(heap[parent]) > 0)
		{
			heap[newest] = heap[parent];
			newest = parent;
			parent = newest / 2;
			swapCount++;
		}
		heap[newest] = newEntry;
		last++;
		ensureCapacity();
	}
	
	public void removeMax()		//remove maximum 
	{
		checkInitialization();
		T root = null;
		
		if(!isEmpty())		//make sure not empty
		{
			root = heap[1];
			heap[1] = heap[last];
			last--;
			reheap(1);
		}
	}
	
	public void ensureCapacity()
	{
		if(last >= heap.length)
		{
			int newCap = 2 * heap.length; 
			capCheck(newCap);
			heap = Arrays.copyOf(heap, newCap);
		}
	}
	
	public void reheap(int root)
  {
      boolean done = false;
      T orphan = heap[root];
      int leftChild = 2 * root;

      while (!done && (leftChild <= last) )
      {
          int greaterChild = leftChild; 
          int rightChild = leftChild + 1;

          if ( (rightChild <= last) && 		//when greater compare with 
                heap[rightChild].compareTo(heap[greaterChild]) > 0)
          {
              greaterChild = rightChild;
          }

          if (orphan.compareTo(heap[greaterChild]) < 0)
          {
              heap[root] = heap[greaterChild];
              root = greaterChild;
              leftChild = 2 * root;
          } 
          else
          {
              done = true;
          }
          swapCount++;
      }

      heap[root] = orphan;
  }

	
	private void checkInitialization()
  {
      if (!initialized)
      {
          throw new SecurityException ("MaxHeap object isn't initialized proprely.");
      }
  }
	
	public int getSize()
	{
		return last;
	}
	
	public void printArray() 
	{
		 for (int i = 1; i < 11; i++) 
		 {
	            System.out.print(heap[i] + " ");
	     }
		 System.out.println(" ");
		 System.out.println(swapCount);
	}
	
	public int getElement(int i)
	{
		return (int)heap[i];
	}
	
	private boolean isEmpty()
	{
		return last < 1;
	}
	
	public int getSwaps()		//how many swaps
	{
		return swapCount;
	}

}
