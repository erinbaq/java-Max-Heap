package Assignment2;
//Russ Erin Baquiran
//CS2400
//Assignment 2- max-heap (sequential and optimal)
import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;
import java.io.FileWriter;
import java.io.IOException;

public class MaxHeapDriver {
	public static void main(String[] args)throws IOException
	{
		FileWriter fileWrite = new FileWriter("output.txt");	//where writing to
		
		ArrayList<Integer> tempArray = new ArrayList<Integer>();
		
		try {
			Scanner data = new Scanner(new File("data.txt"));
			while(data.hasNextInt())
			{
				tempArray.add(data.nextInt());
			}
			data.close();
			
		} catch (FileNotFoundException e) {
			System.out.println("File not found");		//if file dne
		}
		
		MaxHeap heapSeq = new MaxHeap(tempArray.size());
		
		for(int i = 0; i < tempArray.size(); i++)
		{
			heapSeq.add(i+1);
		}
				//output needed for sequential
		try{
			fileWrite.write("Heap built using sequential insertions: ");
			for(int i = 1; i < 11; i++)
			{
				fileWrite.write(heapSeq.getElement(i) + ",");
				
			}
			fileWrite.write(".... \nNumber of swaps in the heap creation: ");
			fileWrite.write(heapSeq.getSwaps() + " \n");
			fileWrite.flush();
			//fileWrite.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		for(int i = 0; i < 10; i++)
		{
			heapSeq.removeMax();
		}
				//into output.txt
		try{
			fileWrite.write("Heap after 10 removals: ");
			for(int i = 1; i < 11; i++)
			{
				fileWrite.write(heapSeq.getElement(i) + ",");
				
			}
			fileWrite.write("....\n \n \n");
			fileWrite.flush();
		} catch (IOException e) {
			e.printStackTrace();
		} 
		MaxHeap myHeap = new MaxHeap(tempArray);
		
				//get output for optimal method
		
		try{
			fileWrite.write("Heap built using optimal method: ");
			for(int i = 1; i < 11; i++)
			{
				fileWrite.write(myHeap.getElement(i) + ",");
				
			}
			fileWrite.write(".... \nNumber of swaps in the heap creation: ");
			fileWrite.write(myHeap.getSwaps() + " \n");
			fileWrite.flush();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		for(int i = 0; i < 10; i++)
		{
			myHeap.removeMax();
		}
				//write into output.txt
		try{
			fileWrite.write("Heap after 10 removals: ");
			for(int i = 1; i < 11; i++)
			{
				fileWrite.write(myHeap.getElement(i) + ",");		
			}
			fileWrite.write("....");
			fileWrite.flush();
			fileWrite.close();
		} catch (IOException e) {
			e.printStackTrace();
		} 
	}
}

